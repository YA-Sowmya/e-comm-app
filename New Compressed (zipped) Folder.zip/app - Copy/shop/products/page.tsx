import ProductsPageClient from "./ProductsPageClient";

export default function ProductsPage() {
  return <ProductsPageClient />;
}
