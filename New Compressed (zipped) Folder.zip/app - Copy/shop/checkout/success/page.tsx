export default function Success() {
  return (
    <div>
      <h1>Payment Successful </h1>
      <p>Thank you for your purchase!</p>
    </div>
  );
}
