export default function OrdersPage() {
  return (
    <div className="bg-white rounded-xl text-cherry h-screen p-6">
      Coming soon
    </div>
  );
}
